# Fortunex

منصة شخصية لإدارة ونشر مشاريع المواقع التي تبنيها لعملائك. تكتشف تلقائيًا
الموارد التي يحتاجها كل مشروع (ملفات ثابتة فقط، أو Worker، أو Worker + D1)
ولا تُنشئ أي مورد غير مطلوب، ثم تنشره فعليًا على Cloudflare.

هذه نسخة **MVP** حسب الأولوية التي طُلبت: Dashboard، Projects، Clients،
Upload + Analysis، Resource Detection، Cloudflare (OAuth + API Token)،
Deployment Engine، Versions، Logs، Security الأساسية.

---

## 1. بنية الملفات

```
fortunex/
├── backend/
│   ├── src/
│   │   ├── index.js                 نقطة دخول الخادم (Express)
│   │   ├── db.js                    قاعدة بيانات SQLite + المخطط
│   │   ├── middleware/auth.js       حماية المسارات بـ JWT
│   │   ├── routes/
│   │   │   ├── auth.js              تسجيل الدخول
│   │   │   ├── clients.js           CRUD العملاء
│   │   │   ├── projects.js          CRUD المشاريع + رفع ZIP + Deploy
│   │   │   └── cloudflare.js        OAuth + اتصال عبر API Token
│   │   ├── services/
│   │   │   ├── crypto.js            تشفير AES-256-GCM لأسرار Cloudflare
│   │   │   ├── resourceDetector.js  محرّك اكتشاف الموارد (الميزة الأهم)
│   │   │   ├── deploymentEngine.js  ينسّق عملية Deploy الكاملة
│   │   │   └── deploymentProviders/
│   │   │       ├── DeploymentProvider.js   العقد العام لأي مزوّد نشر
│   │   │       └── CloudflareProvider.js   تنفيذ Cloudflare (Workers/D1/Pages)
│   │   └── utils/logger.js          تسجيل السجلات في قاعدة البيانات
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── pages/        Dashboard, Projects, ProjectDetail, Clients, Settings, Login
│   │   ├── components/   Sidebar, StatCard, StatusBadge, Modal, Toast, DeploymentLog
│   │   ├── api.js        طبقة الاتصال بالـ backend
│   │   └── styles.css    نظام التصميم (design tokens)
│   └── .env.example
└── README.md
```

**Architecture** مفصولة بوضوح: Frontend / Backend / Auth / Projects / Clients /
Cloudflare Integration / Deployment Engine (مع Provider abstraction قابل للتوسع
مستقبلًا لـ Vercel/Netlify/Railway) / Resource Detection / Database / Logs / Secrets.

---

## 2. طريقة التشغيل محليًا

### المتطلبات
- Node.js 20 أو أحدث
- npm

### الخطوات

```bash
# 1) الباك-إند
cd fortunex/backend
npm install
cp .env.example .env
# عدّل .env كما هو موضّح في القسم 4 أدناه، ثم:
npm run dev
# يعمل على http://localhost:4000

# 2) الفرونت إند (في طرفية أخرى)
cd fortunex/frontend
npm install
cp .env.example .env
npm run dev
# يعمل على http://localhost:5173
```

افتح `http://localhost:5173` وسجّل الدخول بالبريد وكلمة المرور اللذين ضبطتهما
في `backend/.env` (انظر القسم التالي).

---

## 3. المتطلبات (الحزم) التي سيتم تثبيتها

**Backend:** express, better-sqlite3, cors, dotenv, multer, adm-zip,
jsonwebtoken, bcryptjs, nanoid.

**Frontend:** react, react-dom, react-router-dom, vite, @vitejs/plugin-react.

لا توجد اعتماديات إضافية غير ضرورية عمدًا لإبقاء المشروع خفيفًا.

---

## 4. إعدادات مطلوبة قبل التشغيل الفعلي

افتح `backend/.env` واملأ:

1. **JWT_SECRET** — أي نص عشوائي طويل.
2. **ENCRYPTION_KEY** — 64 محرف hex، ولّده بـ:
   ```bash
   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
   ```
3. **ADMIN_EMAIL** و **ADMIN_PASSWORD_HASH** — حساب الدخول الوحيد للوحة.
   ولّد الهاش بـ:
   ```bash
   node -e "console.log(require('bcryptjs').hashSync('كلمة_مرورك', 10))"
   ```
   (نفّذها من داخل `backend/` بعد `npm install` حتى تجد حزمة bcryptjs).

4. **Cloudflare** — يوجد مساران، اختر ما يناسبك:
   - **الأسهل الآن (API Token):** من Cloudflare Dashboard ← My Profile ←
     API Tokens ← Create Token، أعطه صلاحيات: `Account.Workers Scripts:Edit`,
     `Account.D1:Edit`, `Account.Cloudflare Pages:Edit`, `Account.Account Settings:Read`.
     ثم الصقه من صفحة **Settings** داخل Fortunex ("الاتصال عبر API Token").
     لا حاجة لأي متغيّر بيئة إضافي لهذا المسار.
   - **OAuth الكامل:** يتطلب تطبيق OAuth مسجّل فعليًا لدى Cloudflare (ليس متاحًا
     بالتسجيل الذاتي المفتوح لكل مطوّر في كل الحسابات). إن حصلت عليه، املأ
     `CLOUDFLARE_CLIENT_ID` و `CLOUDFLARE_CLIENT_SECRET` و
     `CLOUDFLARE_REDIRECT_URI` في `.env`، وسيعمل زر "Connect Cloudflare" في
     الإعدادات مباشرة.

---

## 5. ما الذي يعمل فعليًا الآن

- تسجيل الدخول بحساب واحد محمي بـ JWT.
- إنشاء/تعديل/حذف العملاء والمشاريع (بيانات حقيقية في SQLite، وليست وهمية).
- رفع مشروع ZIP، فك ضغطه، وتحليل بنيته فعليًا (`resourceDetector.js`) لتحديد
  إن كان يحتاج Worker/D1/Env Vars أو Static فقط — بدون افتراضات جاهزة.
- نظام إصدارات حقيقي: كل رفعة = نسخة جديدة محفوظة على القرص، مع إمكانية تعيين
  نسخة سابقة كحالية (rollback) دون حذف أي نسخة.
- تخزين آمن لأسرار Cloudflare (تشفير AES-256-GCM قبل الحفظ، ولا تُعرض لاحقًا).
- محرّك نشر حقيقي (`deploymentEngine.js` + `CloudflareProvider.js`) يستدعي
  Cloudflare API فعليًا لإنشاء/تحديث Worker، وإنشاء D1 عند الحاجة، ورفع الملفات
  إلى Cloudflare Pages — وليس مجرد أزرار شكلية.
- سجل نشر حي (Logs) لكل خطوة، منشور في تبويب "السجلات" لكل مشروع.
- فصل صلاحيات: كل مسار API (عدا تسجيل الدخول وcallback الخاص بـ OAuth) محمي.

---

## 6. ما الذي يحتاج Credentials منك لتشغيله كاملًا

- **JWT_SECRET / ENCRYPTION_KEY / ADMIN_PASSWORD_HASH** — بدونها لن يعمل تسجيل
  الدخول ولا تشفير الأسرار (انظر القسم 4).
- **Cloudflare API Token أو OAuth App** — بدونه، تحليل الموارد ورفع الملفات
  يعملان، لكن خطوة "Deploy" الفعلية (إنشاء Worker/D1 والرفع لـ Pages) ستفشل
  برسالة واضحة تطلب منك ربط Cloudflare أولًا.
- لم يُستخدم أي بيانات وهمية بديلة للمنطق الحقيقي؛ الأماكن التي تحتاج بيانات
  اعتماد خارجية موضّحة بوضوح في الكود والواجهة (رسائل الخطأ تشرح ماذا ينقص).

---

## 7. خطوات اختبار المشروع من البداية حتى نشر حقيقي

1. شغّل الباك-إند والفرونت إند كما في القسم 2، واملأ `.env` كما في القسم 4.
2. سجّل الدخول من `http://localhost:5173`.
3. أنشئ عميلًا من صفحة "العملاء".
4. أنشئ مشروعًا جديدًا من "المشاريع" واربطه بهذا العميل.
5. من صفحة المشروع، اضغط "رفع نسخة جديدة (ZIP)" وارفع مشروعًا حقيقيًا:
   - جرّب أولًا مشروع HTML/CSS/JS بسيط (بدون package.json) — يجب أن يظهر في
     تبويب "الموارد": Static Assets فقط.
   - ثم جرّب مشروعًا يحتوي على `wrangler.toml` مع Worker (وربما D1) — يجب أن
     تظهر الموارد المطابقة.
6. راجع الموارد المكتشفة في تبويب "الموارد".
7. اذهب إلى تبويب "Cloudflare" في المشروع، وأضف اتصالًا (API Token هو الأسرع)
   واربطه بالمشروع.
8. اضغط زر "نشر (Deploy)" في أعلى الصفحة.
9. راقب تبويب "السجلات" — سترى كل خطوة (تجهيز الموارد، رفع الملفات، النتيجة).
10. عند النجاح، ستحصل على رابط مباشر (`https://<slug>.pages.dev` أو نطاقك إن
    ربطته لاحقًا من لوحة Cloudflare نفسها).
11. جرّب رفع نسخة v2 من نفس المشروع، ثم استخدم "تعيين كحالية" على v1 للتأكد
    من أن نظام الإصدارات يعمل دون حذف أي نسخة.

---

## ملاحظات أمان

- لا تُحفظ أي كلمة مرور Cloudflare في أي مكان.
- كل الأسرار (Cloudflare tokens) مشفّرة بـ AES-256-GCM في قاعدة البيانات، ولا
  تُعاد أبدًا في استجابات الـ API.
- الـ logger يخفي تلقائيًا أي نص يشبه Bearer token أو مفتاحًا طويلًا قبل حفظه.
- كل مسارات API محمية بـ JWT عدا تسجيل الدخول ومسار Cloudflare OAuth callback
  (الذي يستدعيه Cloudflare نفسه عبر إعادة توجيه المتصفح).
