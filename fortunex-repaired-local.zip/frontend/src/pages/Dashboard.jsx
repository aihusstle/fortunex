import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import StatCard from '../components/StatCard.jsx';
import StatusBadge from '../components/StatusBadge.jsx';
import { useToast } from '../components/Toast.jsx';

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const navigate = useNavigate();
  const showToast = useToast();

  useEffect(() => {
    api.getStats().then(setStats).catch((err) => showToast(err.message, 'error'));
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">نظرة عامة</h1>
          <p className="page-subtitle">ملخص سريع عن مشاريعك وعملائك وآخر عمليات النشر</p>
        </div>
      </div>

      {stats && (
        <div className="stat-grid">
          <StatCard label="إجمالي المشاريع" value={stats.totalProjects} />
          <StatCard label="مشاريع منشورة" value={stats.deployedProjects} />
          <StatCard label="عدد العملاء" value={stats.totalClients} />
        </div>
      )}

      <div className="panel">
        <h3 style={{ margin: '0 0 16px', fontSize: 15 }}>آخر عمليات النشر</h3>
        {!stats || stats.recentDeployments.length === 0 ? (
          <div className="empty-state">لا توجد عمليات نشر بعد. أنشئ مشروعًا وارفع نسخته الأولى للبدء.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>المشروع</th>
                <th>الحالة</th>
                <th>الرابط</th>
                <th>وقت البدء</th>
              </tr>
            </thead>
            <tbody>
              {stats.recentDeployments.map((d) => (
                <tr key={d.id} onClick={() => navigate(`/projects/${d.project_id}`)}>
                  <td>{d.project_name}</td>
                  <td><StatusBadge status={d.status} /></td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12.5 }}>
                    {d.live_url || '—'}
                  </td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 12.5 }}>
                    {new Date(d.started_at).toLocaleString('ar')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
