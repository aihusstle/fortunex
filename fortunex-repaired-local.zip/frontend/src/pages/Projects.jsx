import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import StatusBadge from '../components/StatusBadge.jsx';
import Modal from '../components/Modal.jsx';
import { useToast } from '../components/Toast.jsx';

const PROJECT_TYPES = [
  { value: 'landing-page', label: 'Landing Page' },
  { value: 'static', label: 'Static Website' },
  { value: 'full-stack', label: 'Full-stack' },
  { value: 'e-commerce', label: 'E-commerce' },
  { value: 'booking-system', label: 'Booking System' },
  { value: 'custom', label: 'Custom' },
];

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [clients, setClients] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: '', clientId: '', description: '', projectType: 'custom' });
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();
  const showToast = useToast();

  function load() {
    api.getProjects().then(setProjects).catch((err) => showToast(err.message, 'error'));
    api.getClients().then(setClients).catch(() => {});
  }

  useEffect(load, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const project = await api.createProject(form);
      showToast('تم إنشاء المشروع بنجاح');
      setShowModal(false);
      setForm({ name: '', clientId: '', description: '', projectType: 'custom' });
      navigate(`/projects/${project.id}`);
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">المشاريع</h1>
          <p className="page-subtitle">كل المشاريع التي تديرها عبر Fortunex</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ مشروع جديد</button>
      </div>

      <div className="panel">
        {projects.length === 0 ? (
          <div className="empty-state">لا توجد مشاريع بعد. اضغط "مشروع جديد" للبدء.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>الاسم</th>
                <th>العميل</th>
                <th>النوع</th>
                <th>حالة النشر</th>
                <th>آخر نشر</th>
              </tr>
            </thead>
            <tbody>
              {projects.map((p) => (
                <tr key={p.id} onClick={() => navigate(`/projects/${p.id}`)}>
                  <td>{p.name}</td>
                  <td>{p.client_name || '—'}</td>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12.5, color: 'var(--text-secondary)' }}>
                    {p.project_type}
                  </td>
                  <td><StatusBadge status={p.deployment_status} /></td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 12.5 }}>
                    {p.last_deployment_at ? new Date(p.last_deployment_at).toLocaleString('ar') : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <Modal title="مشروع جديد" onClose={() => setShowModal(false)}>
          <form onSubmit={handleCreate}>
            <div className="field">
              <label>اسم المشروع</label>
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required autoFocus />
            </div>
            <div className="field">
              <label>العميل (اختياري)</label>
              <select value={form.clientId} onChange={(e) => setForm({ ...form, clientId: e.target.value })}>
                <option value="">— بدون عميل الآن —</option>
                {clients.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div className="field">
              <label>نوع المشروع (يمكن تعديله بعد تحليل الملفات)</label>
              <select value={form.projectType} onChange={(e) => setForm({ ...form, projectType: e.target.value })}>
                {PROJECT_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
            </div>
            <div className="field">
              <label>الوصف</label>
              <textarea rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn btn-primary" type="submit" disabled={saving}>
                {saving ? 'جارٍ الإنشاء...' : 'إنشاء المشروع'}
              </button>
              <button className="btn btn-ghost" type="button" onClick={() => setShowModal(false)}>إلغاء</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
