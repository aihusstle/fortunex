import { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../api.js';
import StatusBadge from '../components/StatusBadge.jsx';
import DeploymentLog from '../components/DeploymentLog.jsx';
import { useToast } from '../components/Toast.jsx';

const TABS = ['نظرة عامة', 'الموارد', 'الإصدارات', 'Cloudflare', 'السجلات'];

export default function ProjectDetail() {
  const { id } = useParams();
  const [project, setProject] = useState(null);
  const [tab, setTab] = useState(TABS[0]);
  const [uploading, setUploading] = useState(false);
  const [deploying, setDeploying] = useState(false);
  const [lastDetection, setLastDetection] = useState(null);
  const [connections, setConnections] = useState([]);
  const [tokenInput, setTokenInput] = useState('');
  const fileInputRef = useRef(null);
  const showToast = useToast();

  function load() {
    api.getProject(id).then(setProject).catch((err) => showToast(err.message, 'error'));
  }

  useEffect(load, [id]);

  useEffect(() => {
    if (tab === 'Cloudflare') {
      api.getCloudflareConnections().then(setConnections).catch(() => {});
    }
  }, [tab]);

  async function handleUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { detection } = await api.uploadVersion(id, file);
      setLastDetection(detection);
      showToast('تم رفع المشروع وتحليل الموارد بنجاح');
      setTab('الموارد');
      load();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  }

  async function handleDeploy(versionId) {
    setDeploying(true);
    try {
      const result = await api.deployProject(id, versionId);
      showToast(`تم النشر بنجاح: ${result.liveUrl}`);
      setTab('السجلات');
      load();
    } catch (err) {
      showToast(err.message, 'error');
      setTab('السجلات');
      load();
    } finally {
      setDeploying(false);
    }
  }

  async function handleRollback(versionId) {
    try {
      await api.rollbackVersion(id, versionId);
      showToast('تم تعيينها كنسخة حالية. اضغط نشر لتفعيلها فعليًا.');
      load();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  async function handleLinkConnection(connectionId) {
    try {
      await api.linkCloudflareToProject(id, connectionId);
      showToast('تم ربط اتصال Cloudflare بالمشروع');
      load();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  async function handleConnectToken(e) {
    e.preventDefault();
    if (!tokenInput) return;
    try {
      const conn = await api.connectCloudflareToken(tokenInput);
      showToast(`تم الاتصال بحساب Cloudflare: ${conn.accountName || conn.accountId}`);
      setTokenInput('');
      const list = await api.getCloudflareConnections();
      setConnections(list);
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  if (!project) return null;

  const detection = lastDetection || {
    needsStatic: !!project.needs_static,
    needsWorker: !!project.needs_worker,
    needsDatabase: !!project.needs_database,
    envVars: JSON.parse(project.env_vars_json || '[]'),
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">{project.name}</h1>
          <p className="page-subtitle">{project.description || 'لا يوجد وصف'}</p>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <StatusBadge status={project.deployment_status} />
          <input ref={fileInputRef} type="file" accept=".zip" hidden onChange={handleUpload} />
          <button className="btn btn-ghost" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
            {uploading ? 'جارٍ الرفع والتحليل...' : 'رفع نسخة جديدة (ZIP)'}
          </button>
          <button
            className="btn btn-primary"
            disabled={!project.current_version_id || deploying}
            onClick={() => handleDeploy(project.current_version_id)}
          >
            {deploying ? 'جارٍ النشر...' : 'نشر (Deploy)'}
          </button>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 4, marginBottom: 20, borderBottom: '1px solid var(--border-subtle)' }}>
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className="btn btn-ghost"
            style={{
              borderRadius: 0,
              borderBottom: tab === t ? '2px solid var(--accent)' : '2px solid transparent',
              color: tab === t ? 'var(--text-primary)' : 'var(--text-muted)',
            }}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'نظرة عامة' && (
        <div className="panel">
          <div className="stat-grid" style={{ marginBottom: 0 }}>
            <div className="stat-card"><div className="label">النوع</div><div className="value" style={{ fontSize: 16 }}>{project.project_type}</div></div>
            <div className="stat-card"><div className="label">الرابط الحالي</div><div className="value" style={{ fontSize: 13 }}>{project.live_url || '—'}</div></div>
            <div className="stat-card"><div className="label">آخر نشر</div><div className="value" style={{ fontSize: 13 }}>{project.last_deployment_at ? new Date(project.last_deployment_at).toLocaleString('ar') : '—'}</div></div>
          </div>
        </div>
      )}

      {tab === 'الموارد' && (
        <div className="panel">
          <p className="page-subtitle" style={{ marginBottom: 16 }}>
            هذه الموارد اكتُشفت تلقائيًا من بنية آخر نسخة مرفوعة. راجعها قبل الضغط على نشر.
          </p>
          <div className="resource-list">
            <ResourceLine ok={detection.needsStatic} label="Static Assets — ملفات ثابتة يتم نشرها" />
            <ResourceLine ok={detection.needsWorker} label="Worker — بيئة تنفيذ Backend" />
            <ResourceLine ok={detection.needsDatabase} label="D1 Database — قاعدة بيانات" />
            <ResourceLine
              ok={detection.envVars?.length > 0}
              label={
                detection.envVars?.length > 0
                  ? `Environment Variables (${detection.envVars.length}): ${detection.envVars.join(', ')}`
                  : 'Environment Variables — لا يوجد'
              }
            />
          </div>
          {!project.current_version_id && (
            <div className="empty-state">لم يتم رفع أي نسخة بعد. ارفع ملف ZIP من الأعلى ليبدأ التحليل.</div>
          )}
        </div>
      )}

      {tab === 'الإصدارات' && (
        <div className="panel">
          {project.versions.length === 0 ? (
            <div className="empty-state">لا توجد نسخ بعد.</div>
          ) : (
            <table className="data-table">
              <thead>
                <tr>
                  <th>الإصدار</th>
                  <th>الحالة</th>
                  <th>تاريخ الإنشاء</th>
                  <th>تاريخ النشر</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {project.versions.map((v) => (
                  <tr key={v.id}>
                    <td style={{ fontFamily: 'var(--font-mono)' }}>
                      v{v.version_number} {v.id === project.current_version_id && <span style={{ color: 'var(--accent)' }}> (حالية)</span>}
                    </td>
                    <td><StatusBadge status={v.deployment_status} /></td>
                    <td style={{ color: 'var(--text-muted)', fontSize: 12.5 }}>{new Date(v.created_at).toLocaleString('ar')}</td>
                    <td style={{ color: 'var(--text-muted)', fontSize: 12.5 }}>{v.deployed_at ? new Date(v.deployed_at).toLocaleString('ar') : '—'}</td>
                    <td>
                      {v.id !== project.current_version_id && (
                        <button className="btn btn-ghost" onClick={() => handleRollback(v.id)}>تعيين كحالية</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {tab === 'Cloudflare' && (
        <div className="panel">
          <p className="page-subtitle" style={{ marginBottom: 16 }}>
            اربط حساب Cloudflare بهذا المشروع لتفعيل النشر الفعلي. راجع الإعدادات لإضافة اتصال جديد.
          </p>
          {connections.length === 0 ? (
            <div className="empty-state">لا يوجد اتصال Cloudflare بعد. أضف واحدًا من صفحة الإعدادات، أو أدخل API Token مباشرة هنا.</div>
          ) : (
            <div className="resource-list">
              {connections.map((c) => (
                <div key={c.id} className="resource-item" style={{ justifyContent: 'space-between' }}>
                  <span>{c.account_name || c.account_id}</span>
                  <button
                    className="btn btn-ghost"
                    disabled={project.cloudflare_connection_id === c.id}
                    onClick={() => handleLinkConnection(c.id)}
                  >
                    {project.cloudflare_connection_id === c.id ? 'مرتبط ✓' : 'ربط بهذا المشروع'}
                  </button>
                </div>
              ))}
            </div>
          )}
          <form onSubmit={handleConnectToken} style={{ marginTop: 20 }}>
            <div className="field">
              <label>إضافة اتصال سريع عبر API Token</label>
              <input
                type="password"
                placeholder="Cloudflare API Token"
                value={tokenInput}
                onChange={(e) => setTokenInput(e.target.value)}
              />
              <span className="field-hint">
                يُنشأ من Cloudflare Dashboard ← My Profile ← API Tokens. يُشفَّر فورًا ولا يُعرض لاحقًا.
              </span>
            </div>
            <button className="btn btn-ghost" type="submit">إضافة الاتصال</button>
          </form>
        </div>
      )}

      {tab === 'السجلات' && (
        <div className="panel">
          <DeploymentLog logs={project.logs} />
        </div>
      )}
    </div>
  );
}

function ResourceLine({ ok, label }) {
  return (
    <div className={`resource-item ${ok ? '' : 'skip'}`}>
      <span className="check">{ok ? '✓' : '—'}</span>
      <span>{label}</span>
    </div>
  );
}
