import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../api.js';
import { useToast } from '../components/Toast.jsx';

export default function Settings() {
  const [connections, setConnections] = useState([]);
  const [tokenInput, setTokenInput] = useState('');
  const [params] = useSearchParams();
  const showToast = useToast();

  function load() {
    api.getCloudflareConnections().then(setConnections).catch(() => {});
  }

  useEffect(() => {
    load();
    if (params.get('cloudflare') === 'connected') {
      showToast('تم الاتصال بـ Cloudflare بنجاح');
    } else if (params.get('cloudflare') === 'error') {
      showToast(params.get('message') || 'فشل الاتصال بـ Cloudflare', 'error');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleOAuthConnect() {
    try {
      const { authorizeUrl } = await api.connectCloudflareOAuth();
      window.location.href = authorizeUrl;
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  async function handleTokenConnect(e) {
    e.preventDefault();
    if (!tokenInput) return;
    try {
      const conn = await api.connectCloudflareToken(tokenInput);
      showToast(`تم الاتصال بحساب: ${conn.accountName || conn.accountId}`);
      setTokenInput('');
      load();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  async function handleDelete(id) {
    try {
      await api.deleteCloudflareConnection(id);
      showToast('تم حذف الاتصال');
      load();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">الإعدادات</h1>
          <p className="page-subtitle">إدارة اتصالات Cloudflare العامة لحسابك</p>
        </div>
      </div>

      <div className="panel" style={{ marginBottom: 20 }}>
        <h3 style={{ margin: '0 0 14px', fontSize: 15 }}>اتصالات Cloudflare</h3>
        {connections.length === 0 ? (
          <div className="empty-state">لا يوجد اتصال بعد.</div>
        ) : (
          <div className="resource-list">
            {connections.map((c) => (
              <div key={c.id} className="resource-item" style={{ justifyContent: 'space-between' }}>
                <span>{c.account_name || c.account_id} <span style={{ color: 'var(--text-muted)', fontSize: 12 }}>({new Date(c.created_at).toLocaleDateString('ar')})</span></span>
                <button className="btn btn-danger" onClick={() => handleDelete(c.id)}>حذف</button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="panel" style={{ marginBottom: 20 }}>
        <h3 style={{ margin: '0 0 8px', fontSize: 15 }}>الاتصال عبر OAuth</h3>
        <p className="page-subtitle" style={{ marginBottom: 14 }}>
          يتطلب ضبط CLOUDFLARE_CLIENT_ID و CLOUDFLARE_CLIENT_SECRET في backend/.env (راجع README).
        </p>
        <button className="btn btn-primary" onClick={handleOAuthConnect}>Connect Cloudflare</button>
      </div>

      <div className="panel">
        <h3 style={{ margin: '0 0 8px', fontSize: 15 }}>الاتصال عبر API Token (بديل فوري)</h3>
        <p className="page-subtitle" style={{ marginBottom: 14 }}>
          أنشئ Token محدود الصلاحيات من Cloudflare Dashboard ← My Profile ← API Tokens، ثم الصقه هنا. يُشفَّر فورًا.
        </p>
        <form onSubmit={handleTokenConnect} style={{ maxWidth: 420 }}>
          <div className="field">
            <input type="password" placeholder="Cloudflare API Token" value={tokenInput} onChange={(e) => setTokenInput(e.target.value)} />
          </div>
          <button className="btn btn-ghost" type="submit">إضافة الاتصال</button>
        </form>
      </div>
    </div>
  );
}
