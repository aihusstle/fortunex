import { useEffect, useState } from 'react';
import { api } from '../api.js';
import Modal from '../components/Modal.jsx';
import { useToast } from '../components/Toast.jsx';

export default function Clients() {
  const [clients, setClients] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: '', email: '' });
  const [saving, setSaving] = useState(false);
  const showToast = useToast();

  function load() {
    api.getClients().then(setClients).catch((err) => showToast(err.message, 'error'));
  }

  useEffect(load, []);

  async function handleCreate(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await api.createClient(form);
      showToast('تم إضافة العميل');
      setShowModal(false);
      setForm({ name: '', email: '' });
      load();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">العملاء</h1>
          <p className="page-subtitle">إدارة العملاء والمشاريع المرتبطة بكل منهم</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowModal(true)}>+ عميل جديد</button>
      </div>

      <div className="panel">
        {clients.length === 0 ? (
          <div className="empty-state">لا يوجد عملاء بعد.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>الاسم</th>
                <th>البريد الإلكتروني</th>
                <th>عدد المشاريع</th>
                <th>تاريخ الإنشاء</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((c) => (
                <tr key={c.id}>
                  <td>{c.name}</td>
                  <td>{c.email || '—'}</td>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>{c.projects?.length || 0}</td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 12.5 }}>{new Date(c.created_at).toLocaleDateString('ar')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <Modal title="عميل جديد" onClose={() => setShowModal(false)}>
          <form onSubmit={handleCreate}>
            <div className="field">
              <label>الاسم</label>
              <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required autoFocus />
            </div>
            <div className="field">
              <label>البريد الإلكتروني (اختياري)</label>
              <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn btn-primary" type="submit" disabled={saving}>
                {saving ? 'جارٍ الإضافة...' : 'إضافة العميل'}
              </button>
              <button className="btn btn-ghost" type="button" onClick={() => setShowModal(false)}>إلغاء</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
