const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';

function getToken() {
  return localStorage.getItem('fortunex_token');
}

export function setToken(token) {
  if (token) localStorage.setItem('fortunex_token', token);
  else localStorage.removeItem('fortunex_token');
}

async function request(path, { method = 'GET', body, isForm = false } = {}) {
  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (!isForm && body) headers['Content-Type'] = 'application/json';

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: isForm ? body : body ? JSON.stringify(body) : undefined,
  });

  if (res.status === 401) {
    setToken(null);
    window.location.href = '/login';
    throw new Error('انتهت الجلسة، سجّل الدخول من جديد');
  }

  if (res.status === 204) return null;

  const data = await res.json().catch(() => null);
  if (!res.ok) {
    throw new Error(data?.error || `فشل الطلب (HTTP ${res.status})`);
  }
  return data;
}

export const api = {
  login: (email, password) => request('/auth/login', { method: 'POST', body: { email, password } }),

  getStats: () => request('/projects/stats/overview'),

  getClients: () => request('/clients'),
  getClient: (id) => request(`/clients/${id}`),
  createClient: (data) => request('/clients', { method: 'POST', body: data }),
  updateClient: (id, data) => request(`/clients/${id}`, { method: 'PUT', body: data }),
  deleteClient: (id) => request(`/clients/${id}`, { method: 'DELETE' }),

  getProjects: () => request('/projects'),
  getProject: (id) => request(`/projects/${id}`),
  createProject: (data) => request('/projects', { method: 'POST', body: data }),
  updateProject: (id, data) => request(`/projects/${id}`, { method: 'PUT', body: data }),
  deleteProject: (id) => request(`/projects/${id}`, { method: 'DELETE' }),
  uploadVersion: (id, file) => {
    const form = new FormData();
    form.append('file', file);
    return request(`/projects/${id}/versions`, { method: 'POST', body: form, isForm: true });
  },
  rollbackVersion: (projectId, versionId) =>
    request(`/projects/${projectId}/versions/${versionId}/rollback`, { method: 'POST' }),
  deployProject: (id, versionId) => request(`/projects/${id}/deploy`, { method: 'POST', body: { versionId } }),
  getProjectLogs: (id) => request(`/projects/${id}/logs`),

  getCloudflareConnections: () => request('/cloudflare/connections'),
  connectCloudflareOAuth: () => request('/cloudflare/connect'),
  connectCloudflareToken: (apiToken) =>
    request('/cloudflare/connect-with-token', { method: 'POST', body: { apiToken } }),
  deleteCloudflareConnection: (id) => request(`/cloudflare/connections/${id}`, { method: 'DELETE' }),
  linkCloudflareToProject: (projectId, connectionId) =>
    request(`/cloudflare/projects/${projectId}/link`, { method: 'POST', body: { connectionId } }),
};
