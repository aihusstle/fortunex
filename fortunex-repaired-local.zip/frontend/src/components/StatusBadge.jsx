const STATUS_MAP = {
  success: { label: 'ناجح', cls: 'status-success' },
  deployed: { label: 'منشور', cls: 'status-success' },
  running: { label: 'جارٍ التنفيذ', cls: 'status-running' },
  pending: { label: 'قيد الانتظار', cls: 'status-warning' },
  failed: { label: 'فشل', cls: 'status-danger' },
  not_deployed: { label: 'لم يُنشر بعد', cls: 'status-neutral' },
  draft: { label: 'مسودة', cls: 'status-neutral' },
  active: { label: 'نشط', cls: 'status-success' },
};

export default function StatusBadge({ status }) {
  const info = STATUS_MAP[status] || { label: status || 'غير معروف', cls: 'status-neutral' };
  return (
    <span className={`status-pill ${info.cls}`}>
      <span className="dot-indicator" />
      {info.label}
    </span>
  );
}
