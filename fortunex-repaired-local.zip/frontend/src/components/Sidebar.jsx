import { NavLink } from 'react-router-dom';
import { setToken } from '../api.js';

const NAV_ITEMS = [
  { to: '/', label: 'نظرة عامة', end: true },
  { to: '/projects', label: 'المشاريع' },
  { to: '/clients', label: 'العملاء' },
  { to: '/settings', label: 'الإعدادات' },
];

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        Fortunex<span className="dot">.</span>
      </div>
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) => `sidebar-nav-item${isActive ? ' active' : ''}`}
          >
            {item.label}
          </NavLink>
        ))}
      </nav>
      <div className="sidebar-footer">
        <div style={{ marginBottom: 8 }}>منصة إدارة مشاريع العملاء</div>
        <button
          className="btn btn-ghost"
          style={{ width: '100%', padding: '7px 10px', fontSize: 12.5 }}
          onClick={() => {
            setToken(null);
            window.location.href = '/login';
          }}
        >
          تسجيل الخروج
        </button>
      </div>
    </aside>
  );
}
