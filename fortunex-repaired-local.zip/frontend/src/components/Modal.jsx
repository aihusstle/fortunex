export default function Modal({ title, onClose, children, footer }) {
  return (
    <div className="modal-overlay" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-box">
        <h3 className="modal-title">{title}</h3>
        {children}
        {footer && <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-start', marginTop: 20 }}>{footer}</div>}
      </div>
    </div>
  );
}
