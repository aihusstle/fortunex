export default function DeploymentLog({ logs }) {
  if (!logs || logs.length === 0) {
    return <div className="empty-state">لا توجد سجلات بعد. ابدأ عملية رفع أو نشر لرؤية التفاصيل هنا.</div>;
  }

  const ordered = [...logs].reverse(); // الأقدم أولًا كما في طرفية حقيقية

  return (
    <div className="deploy-log">
      {ordered.map((l) => (
        <div key={l.id} className={l.level === 'error' ? 'line-error' : 'line-info'}>
          <span className="line-muted">[{new Date(l.created_at).toLocaleTimeString('en-GB')}]</span> {l.message}
        </div>
      ))}
    </div>
  );
}
