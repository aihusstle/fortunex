import crypto from 'node:crypto';

// نستخدم AES-256-GCM لتشفير أي secret قبل حفظه في قاعدة البيانات.
// المفتاح يأتي من ENCRYPTION_KEY في .env (64 محرف hex = 32 بايت).

function getKey() {
  const hex = process.env.ENCRYPTION_KEY;
  if (!hex || hex.length !== 64) {
    throw new Error(
      'ENCRYPTION_KEY غير مضبوط بشكل صحيح في .env — يجب أن يكون 64 محرف hex (32 بايت). ' +
      'ولّده بالأمر: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"'
    );
  }
  return Buffer.from(hex, 'hex');
}

export function encryptSecret(plainText) {
  const key = getKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(String(plainText), 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  // نخزن iv + authTag + النص المشفر معًا كسلسلة base64 واحدة
  return Buffer.concat([iv, authTag, encrypted]).toString('base64');
}

export function decryptSecret(payloadBase64) {
  const key = getKey();
  const raw = Buffer.from(payloadBase64, 'base64');
  const iv = raw.subarray(0, 12);
  const authTag = raw.subarray(12, 28);
  const encrypted = raw.subarray(28);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);
  const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
  return decrypted.toString('utf8');
}
