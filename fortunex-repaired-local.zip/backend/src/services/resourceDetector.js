import fs from 'node:fs';
import path from 'node:path';

/**
 * هذه هي الميزة الأهم في Fortunex: تحليل بنية مشروع مرفوع (بعد فك ضغطه)
 * لتحديد الموارد الحقيقية التي يحتاجها — بدون افتراض قاعدة بيانات أو
 * Backend إذا لم يكن المشروع يحتاجهما فعلًا.
 *
 * النتيجة: { needsStatic, needsWorker, needsDatabase, envVars, reasons, projectTypeGuess }
 */

const DB_SIGNS = [
  'd1', 'sqlite', 'prisma', 'drizzle', 'mongoose', 'pg', 'mysql2', 'postgres',
  'better-sqlite3', 'knex', 'typeorm', 'supabase'
];

const BACKEND_FRAMEWORKS = [
  'express', 'hono', 'fastify', 'koa', '@cloudflare/workers-types',
  'itty-router', 'next', 'nuxt', 'remix', 'sveltekit'
];

function walk(dir, fileList = [], baseDir = dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    if (['node_modules', '.git', 'dist', 'build', '.next'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walk(full, fileList, baseDir);
    } else {
      fileList.push(path.relative(baseDir, full));
    }
  }
  return fileList;
}

function readJsonSafe(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return null;
  }
}

export function detectResources(projectDir) {
  const files = walk(projectDir);
  const reasons = [];
  let needsWorker = false;
  let needsDatabase = false;
  const envVars = new Set();

  // 1) هل هناك package.json؟ حلّل الاعتمادات
  const pkgPath = files.find((f) => f === 'package.json');
  let deps = {};
  if (pkgPath) {
    const pkg = readJsonSafe(path.join(projectDir, pkgPath));
    if (pkg) {
      deps = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };
      const depNames = Object.keys(deps).map((d) => d.toLowerCase());

      if (depNames.some((d) => BACKEND_FRAMEWORKS.some((f) => d.includes(f)))) {
        needsWorker = true;
        reasons.push('تم العثور على مكتبة Backend/إطار عمل في package.json');
      }
      if (depNames.some((d) => DB_SIGNS.some((s) => d.includes(s)))) {
        needsDatabase = true;
        needsWorker = true;
        reasons.push('تم العثور على مكتبة تعامل مع قاعدة بيانات في package.json');
      }
    }
  }

  // 2) وجود wrangler.toml/jsonc يعني أن المشروع مصمم أصلًا كـ Cloudflare Worker
  if (files.some((f) => /wrangler\.(toml|json|jsonc)$/i.test(f))) {
    needsWorker = true;
    reasons.push('تم العثور على ملف wrangler.toml — المشروع مصمم كـ Cloudflare Worker');
    const wranglerFile = files.find((f) => /wrangler\.(toml|json|jsonc)$/i.test(f));
    const content = fs.readFileSync(path.join(projectDir, wranglerFile), 'utf8');
    if (/\[\[d1_databases\]\]/i.test(content) || /"d1_databases"/i.test(content)) {
      needsDatabase = true;
      reasons.push('wrangler.toml يحتوي على تعريف D1 database');
    }
  }

  // 3) وجود مجلدات/ملفات تدل على API أو مسارات خادم
  if (files.some((f) => /^(api|server|functions|worker|workers)\//i.test(f) || /worker\.(js|ts)$/i.test(f))) {
    needsWorker = true;
    reasons.push('تم العثور على مجلد/ملف API أو Server داخل المشروع');
  }

  // 4) وجود ملفات schema أو migrations تدل على قاعدة بيانات
  if (files.some((f) => /schema\.(prisma|sql)$/i.test(f) || /migrations\//i.test(f))) {
    needsDatabase = true;
    needsWorker = true;
    reasons.push('تم العثور على ملفات schema أو migrations تدل على قاعدة بيانات');
  }

  // 5) استخراج متغيرات البيئة من .env.example أو .env.sample
  const envFile = files.find((f) => /^\.env\.(example|sample)$/i.test(f));
  if (envFile) {
    const content = fs.readFileSync(path.join(projectDir, envFile), 'utf8');
    content.split('\n').forEach((line) => {
      const match = line.match(/^\s*([A-Z0-9_]+)\s*=/);
      if (match) envVars.add(match[1]);
    });
    if (envVars.size > 0) reasons.push(`تم استخراج ${envVars.size} متغيّر بيئة من ${envFile}`);
  }

  // 6) إذا لم نجد أي دليل على Backend/DB، فهذا مشروع Static بالكامل
  const hasIndexHtml = files.some((f) => f.toLowerCase() === 'index.html' || /\/index\.html$/i.test(f));
  const isPureStatic = !needsWorker && !needsDatabase;
  if (isPureStatic) {
    reasons.push(hasIndexHtml
      ? 'لم يتم العثور على أي مؤشر Backend أو قاعدة بيانات — سيُنشر كملفات Static فقط'
      : 'لم يتم العثور على مؤشرات Backend/DB، لكن لم يتم العثور أيضًا على index.html — راجع بنية المشروع يدويًا');
  }

  // تخمين مبدئي لنوع المشروع (المستخدم يستطيع تغييره يدويًا لاحقًا)
  let projectTypeGuess = 'static';
  if (needsWorker && needsDatabase) projectTypeGuess = 'full-stack';
  else if (needsWorker) projectTypeGuess = 'backend';
  else if (isPureStatic) projectTypeGuess = 'static';

  return {
    needsStatic: true, // كل مشروع منشور يحتاج ملفات ثابتة على الأقل (حتى لو كانت مجرد شل لتطبيق)
    needsWorker,
    needsDatabase,
    envVars: Array.from(envVars),
    reasons,
    projectTypeGuess,
    fileCount: files.length,
    dependencyCount: Object.keys(deps).length,
  };
}
