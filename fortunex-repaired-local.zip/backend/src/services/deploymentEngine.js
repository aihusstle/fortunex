import path from 'node:path';
import fs from 'node:fs';
import { spawnSync } from 'node:child_process';
import { build } from 'esbuild';
import { nanoid } from 'nanoid';
import { db } from '../db.js';
import { createLogger } from '../utils/logger.js';
import { CloudflareProvider } from './deploymentProviders/CloudflareProvider.js';
import { decryptSecret } from './crypto.js';

// سجل مزوّدي النشر المتاحين. لإضافة مزوّد جديد مستقبلًا (Vercel, Netlify...):
// نفّذ DeploymentProvider ثم أضفه هنا فقط — بدون تعديل أي كود آخر في هذا الملف.
const PROVIDERS = {
  cloudflare: new CloudflareProvider(),
};

export function getProvider(name) {
  const provider = PROVIDERS[name];
  if (!provider) throw new Error(`مزوّد نشر غير معروف: ${name}`);
  return provider;
}

/**
 * ينفّذ عملية نشر حقيقية كاملة لمشروع معيّن:
 * 1. تحقق من المشروع والاتصال بـ Cloudflare
 * 2. تجهيز الموارد المطلوبة فقط (حسب نتيجة Resource Detection المحفوظة في النسخة)
 * 3. تنفيذ النشر عبر المزوّد المختار
 * 4. تسجيل كل خطوة في جدول logs وتحديث حالة deployment
 */
export async function runDeployment({ projectId, versionId }) {
  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(projectId);
  if (!project) throw new Error('المشروع غير موجود');

  const version = db.prepare('SELECT * FROM versions WHERE id = ? AND project_id = ?').get(versionId, projectId);
  if (!version) throw new Error('النسخة غير موجودة');

  if (!project.cloudflare_connection_id) {
    throw new Error('لا يوجد اتصال Cloudflare مرتبط بهذا المشروع. اربط Cloudflare أولًا من صفحة المشروع.');
  }

  const connRow = db.prepare('SELECT * FROM cloudflare_connections WHERE id = ?').get(project.cloudflare_connection_id);
  if (!connRow) throw new Error('اتصال Cloudflare المرتبط بالمشروع لم يعد موجودًا');

  const connection = {
    accountId: connRow.account_id,
    accessToken: decryptSecret(connRow.access_token_enc),
  };

  const deploymentId = nanoid();
  db.prepare(
    `INSERT INTO deployments (id, project_id, version_id, provider, status) VALUES (?, ?, ?, ?, 'running')`
  ).run(deploymentId, projectId, versionId, project.deployment_provider || 'cloudflare');

  const log = createLogger({ projectId, deploymentId });
  const provider = getProvider(project.deployment_provider || 'cloudflare');

  try {
    log('بدء عملية النشر...');
    log(`جاري التحقق من المشروع "${project.name}"...`);

    const detection = JSON.parse(version.detection_json || '{}');
    const envVars = JSON.parse(project.env_vars_json || '[]');
    const projectSlug = slugify(project.name);
    const versionDir = path.resolve(version.storage_path);

    log('جاري تجهيز الموارد المطلوبة فقط بناءً على نتيجة تحليل المشروع...');
    let liveUrl = null;
    let workerName = null;

    if (detection.needsWorker) {
      log('المشروع يحتاج Worker — جاري تجهيزه...');
      const entryFile = findEntryFile(versionDir);
      if (!entryFile) {
        throw new Error('المشروع تم تصنيفه كـ Worker/Backend لكن لم يتم العثور على ملف دخول (index.js/worker.js). راجع بنية المشروع.');
      }

      // مهم: يجب إنشاء/التحقق من D1 قبل نشر الـ Worker حتى نحصل على databaseId
      // ونربطه فعليًا كـ binding حقيقي في نفس طلب رفع الـ Worker (وليس بعده).
      let d1Binding = null;
      if (detection.needsDatabase) {
        log('المشروع يحتاج قاعدة بيانات — جاري إنشاء/التحقق من D1...');
        d1Binding = await provider.ensureDatabase({ connection, projectSlug, log });
      }

      const bundledEntryFile = await bundleWorker({ entryFile, versionDir, log });
      const workerResult = await provider.ensureWorker({
        connection,
        projectSlug,
        entryFile: bundledEntryFile,
        envVars,
        d1Binding,
        log,
      });
      workerName = workerResult.workerName;
    }

    log('جاري رفع الملفات ونشرها...');
    const staticDir = await prepareStaticDir({ versionDir, log });
    const staticResult = await provider.deployStatic({
      connection,
      projectDir: staticDir,
      projectSlug,
      log,
    });
    liveUrl = staticResult.liveUrl;

    log(`تم النشر بنجاح ✓ الرابط: ${liveUrl}`);

    db.prepare(`UPDATE deployments SET status = 'success', live_url = ?, finished_at = datetime('now') WHERE id = ?`)
      .run(liveUrl, deploymentId);
    db.prepare(`UPDATE versions SET deployment_status = 'success', deployed_at = datetime('now') WHERE id = ?`)
      .run(versionId);
    db.prepare(
      `UPDATE projects SET deployment_status = 'success', live_url = ?, current_version_id = ?, last_deployment_at = datetime('now') WHERE id = ?`
    ).run(liveUrl, versionId, projectId);

    return { deploymentId, liveUrl };
  } catch (err) {
    log(`فشل النشر: ${err.message}`, 'error');
    db.prepare(`UPDATE deployments SET status = 'failed', error_message = ?, finished_at = datetime('now') WHERE id = ?`)
      .run(err.message, deploymentId);
    db.prepare(`UPDATE versions SET deployment_status = 'failed' WHERE id = ?`).run(versionId);
    db.prepare(`UPDATE projects SET deployment_status = 'failed' WHERE id = ?`).run(projectId);
    throw err;
  }
}

const BUILD_OUTPUT_CANDIDATES = ['dist', 'build', 'out', 'public'];

/**
 * إصلاح جوهري: كانت deployStatic تنشر مجلد المشروع الخام كما هو دائمًا، حتى لو كان
 * مشروع React/Vite/Vue غير مبني (بدون تشغيل npm run build)، مما يعني نشر كود مصدر
 * غير قابل للتشغيل بدل موقع فعلي. هذه الدالة تكتشف وجود build script في package.json،
 * تُشغّل npm install ثم npm run build فعليًا داخل مجلد النسخة، ثم تعيد مجلد الناتج
 * (dist/build/out/public) ليُنشر بدل المجلد الخام. إذا لم يوجد package.json أو لم يوجد
 * build script، يُعتبر المشروع Static جاهز مسبقًا ويُنشر كما هو (سلوك سابق محفوظ).
 */
async function prepareStaticDir({ versionDir, log }) {
  const pkgPath = path.join(versionDir, 'package.json');
  if (!fs.existsSync(pkgPath)) return versionDir;

  let pkg;
  try {
    pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  } catch {
    log('تعذّرت قراءة package.json كـ JSON صالح — سيُنشر المشروع كما هو دون بناء.', 'error');
    return versionDir;
  }

  if (!pkg.scripts?.build) {
    log('لا يوجد build script في package.json — المشروع يُعتبر Static جاهز مسبقًا وسيُنشر كما هو.');
    return versionDir;
  }

  log('تم العثور على build script — جاري تثبيت الاعتمادات (npm install)...');
  runCmd('npm', ['install', '--no-audit', '--no-fund'], versionDir, 'npm install');

  log('جاري بناء المشروع (npm run build)...');
  runCmd('npm', ['run', 'build'], versionDir, 'npm run build');

  const outputDir = BUILD_OUTPUT_CANDIDATES
    .map((c) => path.join(versionDir, c))
    .find((full) => fs.existsSync(full) && fs.existsSync(path.join(full, 'index.html')));

  if (!outputDir) {
    throw new Error(
      'تم تشغيل npm run build بنجاح لكن لم يتم العثور على مجلد ناتج يحتوي index.html ' +
      '(تم البحث في dist/build/out/public). تحقق من إعدادات build في المشروع.'
    );
  }
  log(`تم البناء بنجاح. سيُنشر محتوى المجلد: ${path.relative(versionDir, outputDir)}`);
  return outputDir;
}

function runCmd(cmd, args, cwd, label) {
  const result = spawnSync(cmd, args, {
    cwd,
    encoding: 'utf8',
    timeout: 5 * 60 * 1000, // 5 دقائق كحد أقصى معقول لتثبيت/بناء مشروع عميل
    maxBuffer: 20 * 1024 * 1024,
  });
  if (result.error) {
    throw new Error(`فشل تشغيل ${label}: ${result.error.message}`);
  }
  if (result.status !== 0) {
    const tail = (result.stderr || result.stdout || '').split('\n').slice(-25).join('\n');
    throw new Error(`فشل ${label} (exit code ${result.status}):\n${tail}`);
  }
  return result;
}

function slugify(name) {
  return String(name)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 50) || `project-${nanoid(6)}`;
}

function findEntryFile(dir) {
  // Never select a frontend entry point such as frontend/src/index.js.
  const explicit = ['worker.js', 'worker.ts', 'backend/worker.js', 'backend/worker.ts', 'server/index.js', 'server/index.ts', 'src/worker.js', 'src/worker.ts'];
  for (const c of explicit) {
    const full = path.join(dir, c);
    if (fs.existsSync(full) && !isFrontendPath(full)) return full;
  }
  const candidates = ['index.js', 'index.ts', 'src/index.js', 'src/index.ts'];
  for (const c of candidates) {
    const full = path.join(dir, c);
    if (fs.existsSync(full) && !isFrontendPath(full) && looksLikeWorker(full)) return full;
  }
  return null;
}

function isFrontendPath(file) {
  const normalized = file.split(path.sep).join('/').toLowerCase();
  return /(^|\/)frontend(\/|$)|(^|\/)client(\/|$)|(^|\/)src\/(main|app)\.(jsx?|tsx?)$/.test(normalized);
}

function looksLikeWorker(file) {
  try {
    const text = fs.readFileSync(file, 'utf8');
    return /export\s+(default|async function|function)|fetch\s*\(|Response\s*\(|Hono|itty-router|from ['"]hono/.test(text);
  } catch {
    return false;
  }
}

async function bundleWorker({ entryFile, versionDir, log }) {
  const outDir = path.join(versionDir, '.fortunex', 'worker');
  fs.mkdirSync(outDir, { recursive: true });
  const outfile = path.join(outDir, 'worker.js');
  log(`تجميع Worker مع الملفات المحلية والاعتمادات: ${path.relative(versionDir, entryFile)}`);
  await build({
    entryPoints: [entryFile],
    outfile,
    bundle: true,
    format: 'esm',
    platform: 'neutral',
    target: 'es2022',
    sourcemap: false,
    minify: false,
    absWorkingDir: versionDir,
    logLevel: 'silent',
    external: ['node:*'],
  });
  return outfile;
}
