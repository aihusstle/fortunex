/**
 * DeploymentProvider — العقد الذي يجب أن يلتزم به أي مزوّد نشر (Cloudflare, Vercel, Netlify...).
 * هذا يسمح بإضافة مزوّدين جدد لاحقًا دون تعديل باقي النظام (Deployment Engine, Routes, UI).
 *
 * أي مزوّد جديد يجب أن يوفّر نفس الدوال بنفس التوقيع.
 */
export class DeploymentProvider {
  /** @returns {string} اسم فريد للمزوّد، مثل "cloudflare" */
  get name() {
    throw new Error('لم يتم تنفيذ name');
  }

  /** يبني رابط تفويض OAuth الذي يُرسَل إليه المستخدم */
  getOAuthAuthorizeUrl(state) {
    throw new Error('لم يتم تنفيذ getOAuthAuthorizeUrl');
  }

  /** يستبدل authorization code بـ access/refresh tokens */
  async exchangeCodeForToken(code) {
    throw new Error('لم يتم تنفيذ exchangeCodeForToken');
  }

  /** ينشر ملفات Static فقط */
  async deployStatic({ connection, projectDir, projectSlug, log }) {
    throw new Error('لم يتم تنفيذ deployStatic');
  }

  /** ينشئ/يحدّث Worker. إذا كان d1Binding موجودًا (من ensureDatabase) يجب ربطه فعليًا كـ binding حقيقي */
  async ensureWorker({ connection, projectSlug, entryFile, envVars, d1Binding, log }) {
    throw new Error('لم يتم تنفيذ ensureWorker');
  }

  /** ينشئ قاعدة بيانات إذا لم تكن موجودة. يجب استدعاؤها قبل ensureWorker حتى يُمرَّر databaseId كـ binding حقيقي */
  async ensureDatabase({ connection, projectSlug, log }) {
    throw new Error('لم يتم تنفيذ ensureDatabase');
  }
}
