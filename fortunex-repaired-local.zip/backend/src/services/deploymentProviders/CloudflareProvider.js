import fs from 'node:fs';
import path from 'node:path';
import { DeploymentProvider } from './DeploymentProvider.js';

const CF_API = 'https://api.cloudflare.com/client/v4';
const CF_OAUTH_AUTHORIZE = 'https://dash.cloudflare.com/oauth2/auth';
const CF_OAUTH_TOKEN = 'https://dash.cloudflare.com/oauth2/token';

// أقل نطاقات (scopes) ممكنة لما تحتاجه Fortunex فعليًا:
// - عرض معلومات الحساب
// - إدارة Workers scripts
// - إدارة D1
// - إدارة Pages
const OAUTH_SCOPES = [
  'account:read',
  'workers.scripts:edit',
  'workers.kv:edit',
  'd1:edit',
  'pages:edit',
].join(' ');

/**
 * ملاحظة مهمة: Cloudflare لا يوفر تطبيقات "OAuth عامة" بنفس شكل Google/GitHub
 * لكل مطوّر خارجي بشكل مفتوح افتراضيًا؛ الطريقة الرسمية المتاحة للمطورين هي:
 *  1) "Cloudflare for Platforms" / OAuth App مسجّل خصيصًا لحسابك عبر طلب من Cloudflare، أو
 *  2) استخدام API Token محدود الصلاحيات ينشئه المستخدم يدويًا من لوحة Cloudflare
 *     (Profile > API Tokens > Create Token) ثم يُدخله مرة واحدة في Fortunex،
 *     ويُخزَّن مشفّرًا فورًا (لا يُعرض لاحقًا في الواجهة ولا في الـ Logs).
 *
 * هذا الملف يطبّق الحالتين: مسار OAuth الكامل إذا توفرت بيانات تطبيق OAuth حقيقية
 * (CLOUDFLARE_CLIENT_ID/SECRET)، ومسار API Token كبديل عملي فوري.
 * راجع README.md لشرح كيف تفعّل كل مسار.
 */
export class CloudflareProvider extends DeploymentProvider {
  get name() {
    return 'cloudflare';
  }

  getOAuthAuthorizeUrl(state) {
    const clientId = process.env.CLOUDFLARE_CLIENT_ID;
    const redirectUri = process.env.CLOUDFLARE_REDIRECT_URI;
    if (!clientId || !redirectUri) {
      throw new Error(
        'CLOUDFLARE_CLIENT_ID أو CLOUDFLARE_REDIRECT_URI غير مضبوطين في .env. ' +
        'إذا لم يكن لديك تطبيق OAuth من Cloudflare بعد، استخدم مسار API Token البديل الموضح في README.'
      );
    }
    const url = new URL(CF_OAUTH_AUTHORIZE);
    url.searchParams.set('response_type', 'code');
    url.searchParams.set('client_id', clientId);
    url.searchParams.set('redirect_uri', redirectUri);
    url.searchParams.set('scope', OAUTH_SCOPES);
    url.searchParams.set('state', state);
    return url.toString();
  }

  async exchangeCodeForToken(code) {
    const clientId = process.env.CLOUDFLARE_CLIENT_ID;
    const clientSecret = process.env.CLOUDFLARE_CLIENT_SECRET;
    const redirectUri = process.env.CLOUDFLARE_REDIRECT_URI;
    const body = new URLSearchParams({
      grant_type: 'authorization_code',
      code,
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: redirectUri,
    });
    const res = await fetch(CF_OAUTH_TOKEN, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
    });
    if (!res.ok) {
      throw new Error(`فشل تبادل رمز OAuth مع Cloudflare (HTTP ${res.status})`);
    }
    return res.json(); // { access_token, refresh_token, expires_in, scope, ... }
  }

  /** يتحقق من الحساب المرتبط بالـ token ويعيد اسم/معرف الحساب لعرضه في الواجهة */
  async verifyAndFetchAccount(accessToken) {
    const res = await fetch(`${CF_API}/accounts`, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error('فشل التحقق من صلاحية Cloudflare token');
    }
    const account = data.result?.[0];
    if (!account) throw new Error('لم يتم العثور على أي حساب Cloudflare مرتبط بهذا الـ token');
    return { accountId: account.id, accountName: account.name };
  }

  async deployStatic({ connection, projectDir, projectSlug, log }) {
    const accessToken = connection.accessToken;
    const accountId = connection.accountId;

    log(`رفع الملفات الثابتة إلى Cloudflare Pages للمشروع "${projectSlug}"...`);

    // 1) إنشاء مشروع Pages إذا لم يكن موجودًا (idempotent: نتجاهل خطأ "already exists")
    const createRes = await fetch(`${CF_API}/accounts/${accountId}/pages/projects`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: projectSlug,
        production_branch: 'main',
      }),
    });
    const createData = await createRes.json();
    if (!createRes.ok && !createData?.errors?.some((e) => /already exists/i.test(e.message))) {
      throw new Error(`فشل إنشاء مشروع Cloudflare Pages: ${JSON.stringify(createData.errors)}`);
    }

    // 2) رفع الملفات عبر Direct Upload API (يتطلب تحضير الملفات كـ FormData)
    // ملاحظة: هذا نموذج مبسّط؛ لمشاريع كبيرة يُفضّل استخدام Wrangler CLI مباشرة من الخادم.
    const form = new FormData();
    const filesList = collectFiles(projectDir);
    for (const relPath of filesList) {
      const abs = path.join(projectDir, relPath);
      const blob = new Blob([fs.readFileSync(abs)]);
      form.append('file', blob, relPath);
    }

    const uploadRes = await fetch(
      `${CF_API}/accounts/${accountId}/pages/projects/${projectSlug}/deployments`,
      {
        method: 'POST',
        headers: { Authorization: `Bearer ${accessToken}` },
        body: form,
      }
    );
    const uploadData = await uploadRes.json();
    if (!uploadRes.ok || !uploadData.success) {
      throw new Error(`فشل رفع الملفات إلى Cloudflare Pages: ${JSON.stringify(uploadData.errors)}`);
    }

    const liveUrl = uploadData.result?.url || `https://${projectSlug}.pages.dev`;
    log(`تم النشر بنجاح: ${liveUrl}`);
    return { liveUrl };
  }

  async ensureWorker({ connection, projectSlug, entryFile, envVars, d1Binding, log }) {
    const accessToken = connection.accessToken;
    const accountId = connection.accountId;
    const workerName = `fortunex-${projectSlug}`;

    log(`إنشاء/تحديث Worker باسم "${workerName}"...`);
    const scriptContent = fs.readFileSync(entryFile, 'utf8');

    const bindings = (envVars || []).map((key) => ({ type: 'plain_text', name: key, text: '' }));
    // ربط D1 الفعلي: إذا كان المشروع يحتاج قاعدة بيانات، تم إنشاؤها مسبقًا
    // (انظر runDeployment في deploymentEngine.js الذي يستدعي ensureDatabase قبل ensureWorker)
    // ونمررها هنا كـ binding حقيقي من نوع "d1" حتى يستطيع الـ Worker استخدامها عبر env.DB.
    if (d1Binding?.databaseId) {
      bindings.push({ type: 'd1', name: 'DB', id: d1Binding.databaseId });
      log(`ربط قاعدة البيانات D1 "${d1Binding.databaseName}" بالـ Worker عبر binding باسم "DB"...`);
    }

    const metadata = {
      main_module: path.basename(entryFile),
      bindings,
      compatibility_date: new Date().toISOString().slice(0, 10),
    };

    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    form.append(
      path.basename(entryFile),
      new Blob([scriptContent], { type: 'application/javascript+module' }),
      path.basename(entryFile)
    );

    const res = await fetch(
      `${CF_API}/accounts/${accountId}/workers/scripts/${workerName}`,
      { method: 'PUT', headers: { Authorization: `Bearer ${accessToken}` }, body: form }
    );
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(`فشل إنشاء/تحديث Worker: ${JSON.stringify(data.errors)}`);
    }
    log(`تم إنشاء/تحديث Worker "${workerName}" بنجاح`);
    return { workerName };
  }

  async ensureDatabase({ connection, projectSlug, log }) {
    const accessToken = connection.accessToken;
    const accountId = connection.accountId;
    const dbName = `fortunex-${projectSlug}-db`;

    log(`التحقق من وجود قاعدة بيانات D1 باسم "${dbName}"...`);
    const listRes = await fetch(`${CF_API}/accounts/${accountId}/d1/database`, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    const listData = await listRes.json();
    let database = listData.result?.find((d) => d.name === dbName);

    if (!database) {
      log(`إنشاء قاعدة بيانات D1 جديدة "${dbName}"...`);
      const createRes = await fetch(`${CF_API}/accounts/${accountId}/d1/database`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name: dbName }),
      });
      const createData = await createRes.json();
      if (!createRes.ok || !createData.success) {
        throw new Error(`فشل إنشاء قاعدة بيانات D1: ${JSON.stringify(createData.errors)}`);
      }
      database = createData.result;
    } else {
      log(`قاعدة البيانات موجودة مسبقًا، سيتم استخدامها`);
    }

    // هذه الدالة تُستدعى قبل ensureWorker (انظر deploymentEngine.js) بالضبط لهذا السبب:
    // نحتاج databaseId هنا لتمريره كـ binding حقيقي من نوع "d1" عند إنشاء/تحديث الـ Worker.
    log(`تم تجهيز قاعدة البيانات "${dbName}" (id: ${database.uuid || database.id})`);
    return { databaseId: database.uuid || database.id, databaseName: dbName };
  }
}

function collectFiles(dir, base = dir, out = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.git'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) collectFiles(full, base, out);
    else out.push(path.relative(base, full));
  }
  return out;
}
