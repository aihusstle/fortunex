import { nanoid } from 'nanoid';
import { db } from '../db.js';

const insertLog = db.prepare(
  `INSERT INTO logs (id, project_id, deployment_id, level, message) VALUES (?, ?, ?, ?, ?)`
);

/**
 * ينشئ دالة log مرتبطة بمشروع/عملية نشر معيّنة.
 * تُستخدم في كل مكان يحتاج تسجيل خطوة (Resource Detection, Deployment...).
 * لا يجب أبدًا تمرير أسرار (tokens/secrets) إلى هذه الدالة.
 */
export function createLogger({ projectId, deploymentId = null }) {
  return function log(message, level = 'info') {
    const safeMessage = redactSecrets(message);
    insertLog.run(nanoid(), projectId, deploymentId, level, safeMessage);
    // eslint-disable-next-line no-console
    console.log(`[${level}] [project:${projectId}] ${safeMessage}`);
  };
}

function redactSecrets(message) {
  if (typeof message !== 'string') return String(message);
  // إخفاء أي شيء يشبه Bearer token أو مفتاح طويل بالخطأ في رسائل السجل
  return message
    .replace(/Bearer\s+[A-Za-z0-9\-_.]+/g, 'Bearer [REDACTED]')
    .replace(/[A-Za-z0-9]{32,}/g, (m) => (m.length > 40 ? '[REDACTED]' : m));
}
