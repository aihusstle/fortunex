import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import './db.js'; // يضمن إنشاء الجداول عند الإقلاع
import { authRouter } from './routes/auth.js';
import { clientsRouter } from './routes/clients.js';
import { projectsRouter } from './routes/projects.js';
import { cloudflareRouter } from './routes/cloudflare.js';
import { requireAuth } from './middleware/auth.js';

const app = express();

app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173' }));
app.use(express.json({ limit: '5mb' }));

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'fortunex-backend' }));

// مسار تسجيل الدخول (عام)
app.use('/api/auth', authRouter);

// كل ما تبقى من مسارات API محمي بتسجيل الدخول (باستثناء /api/cloudflare/callback
// المحمي بمصادقة داخلية خاصة به — راجع routes/cloudflare.js)
app.use('/api/clients', requireAuth, clientsRouter);
app.use('/api/projects', requireAuth, projectsRouter);
app.use('/api/cloudflare', cloudflareRouter);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'حدث خطأ غير متوقع في الخادم' });
});

const port = process.env.PORT || 4000;
app.listen(port, () => {
  console.log(`Fortunex backend يعمل على http://localhost:${port}`);
});
