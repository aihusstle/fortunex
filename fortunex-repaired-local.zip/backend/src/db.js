import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';

const dataDir = path.resolve(process.env.STORAGE_DIR || './storage');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbPath = path.join(dataDir, 'fortunex.db');
export const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ------------------------------------------------------------------
// المخطط: كل الجداول التي تحتاجها Fortunex لإدارة العملاء والمشاريع
// والنسخ وعمليات النشر واتصالات Cloudflare والسجلات.
// ------------------------------------------------------------------
db.exec(`
CREATE TABLE IF NOT EXISTS clients (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  email         TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS cloudflare_connections (
  id                TEXT PRIMARY KEY,
  client_id         TEXT REFERENCES clients(id) ON DELETE SET NULL,
  project_id        TEXT,
  account_id        TEXT NOT NULL,
  account_name      TEXT,
  access_token_enc  TEXT NOT NULL,
  refresh_token_enc TEXT,
  scope             TEXT,
  expires_at        TEXT,
  created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS projects (
  id                    TEXT PRIMARY KEY,
  name                  TEXT NOT NULL,
  client_id             TEXT REFERENCES clients(id) ON DELETE SET NULL,
  description           TEXT,
  project_type          TEXT NOT NULL DEFAULT 'custom',
  status                TEXT NOT NULL DEFAULT 'draft',
  current_version_id    TEXT,
  deployment_status     TEXT NOT NULL DEFAULT 'not_deployed',
  deployment_provider   TEXT DEFAULT 'cloudflare',
  cloudflare_connection_id TEXT REFERENCES cloudflare_connections(id) ON DELETE SET NULL,
  live_url              TEXT,
  needs_worker          INTEGER NOT NULL DEFAULT 0,
  needs_database        INTEGER NOT NULL DEFAULT 0,
  needs_static          INTEGER NOT NULL DEFAULT 1,
  env_vars_json         TEXT NOT NULL DEFAULT '[]',
  created_at            TEXT NOT NULL DEFAULT (datetime('now')),
  last_deployment_at    TEXT
);

CREATE TABLE IF NOT EXISTS versions (
  id            TEXT PRIMARY KEY,
  project_id    TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  version_number INTEGER NOT NULL,
  storage_path  TEXT NOT NULL,
  detection_json TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  deployed_at   TEXT,
  deployment_status TEXT NOT NULL DEFAULT 'not_deployed'
);

CREATE TABLE IF NOT EXISTS deployments (
  id            TEXT PRIMARY KEY,
  project_id    TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  version_id    TEXT NOT NULL REFERENCES versions(id) ON DELETE CASCADE,
  provider      TEXT NOT NULL DEFAULT 'cloudflare',
  status        TEXT NOT NULL DEFAULT 'pending',
  live_url      TEXT,
  started_at    TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at   TEXT,
  error_message TEXT
);

CREATE TABLE IF NOT EXISTS logs (
  id            TEXT PRIMARY KEY,
  project_id    TEXT REFERENCES projects(id) ON DELETE CASCADE,
  deployment_id TEXT REFERENCES deployments(id) ON DELETE CASCADE,
  level         TEXT NOT NULL DEFAULT 'info',
  message       TEXT NOT NULL,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

export default db;
