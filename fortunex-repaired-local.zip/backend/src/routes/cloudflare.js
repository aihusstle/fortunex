import { Router } from 'express';
import { nanoid } from 'nanoid';
import { db } from '../db.js';
import { encryptSecret } from '../services/crypto.js';
import { getProvider } from '../services/deploymentEngine.js';
import { requireAuth } from '../middleware/auth.js';

export const cloudflareRouter = Router();

const pendingStates = new Map(); // state -> { createdAt } لحماية بسيطة ضد CSRF في تدفق OAuth

// ملاحظة: /callback لا يمرّ عبر requireAuth عمدًا — Cloudflare نفسه يستدعيه
// بإعادة توجيه المتصفح مباشرة (GET بدون Authorization header) بعد موافقة المستخدم.
// كل بقية المسارات هنا محمية بتسجيل دخول Fortunex.

// ------------------------------------------------------------------
// مسار 1: OAuth الكامل (يتطلب CLOUDFLARE_CLIENT_ID/SECRET حقيقيين)
// ------------------------------------------------------------------
cloudflareRouter.get('/connect', requireAuth, (req, res) => {
  try {
    const provider = getProvider('cloudflare');
    const state = nanoid();
    pendingStates.set(state, { createdAt: Date.now() });
    const url = provider.getOAuthAuthorizeUrl(state);
    res.json({ authorizeUrl: url });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

cloudflareRouter.get('/callback', async (req, res) => {
  const { code, state } = req.query;
  if (!state || !pendingStates.has(state)) {
    return res.status(400).send('طلب OAuth غير صالح أو منتهي الصلاحية.');
  }
  pendingStates.delete(state);

  try {
    const provider = getProvider('cloudflare');
    const tokenData = await provider.exchangeCodeForToken(code);
    const { accountId, accountName } = await provider.verifyAndFetchAccount(tokenData.access_token);

    const id = nanoid();
    db.prepare(
      `INSERT INTO cloudflare_connections
        (id, account_id, account_name, access_token_enc, refresh_token_enc, scope, expires_at)
       VALUES (?, ?, ?, ?, ?, ?, datetime('now', '+' || ? || ' seconds'))`
    ).run(
      id,
      accountId,
      accountName,
      encryptSecret(tokenData.access_token),
      tokenData.refresh_token ? encryptSecret(tokenData.refresh_token) : null,
      tokenData.scope || '',
      tokenData.expires_in || 21600
    );

    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173';
    res.redirect(`${frontendUrl}/settings?cloudflare=connected&connectionId=${id}`);
  } catch (err) {
    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173';
    res.redirect(`${frontendUrl}/settings?cloudflare=error&message=${encodeURIComponent(err.message)}`);
  }
});

// ------------------------------------------------------------------
// مسار 2 (بديل عملي فوري): إدخال API Token يدويًا من Cloudflare Dashboard
// يُشفَّر فورًا ولا يُعرض أو يُخزَّن كنص واضح أبدًا.
// ------------------------------------------------------------------
cloudflareRouter.post('/connect-with-token', requireAuth, async (req, res) => {
  const { apiToken } = req.body || {};
  if (!apiToken) return res.status(400).json({ error: 'API Token مطلوب' });

  try {
    const provider = getProvider('cloudflare');
    const { accountId, accountName } = await provider.verifyAndFetchAccount(apiToken);

    const id = nanoid();
    db.prepare(
      `INSERT INTO cloudflare_connections (id, account_id, account_name, access_token_enc) VALUES (?, ?, ?, ?)`
    ).run(id, accountId, accountName, encryptSecret(apiToken));

    res.status(201).json({ id, accountId, accountName, connected: true });
  } catch (err) {
    res.status(400).json({ error: `فشل التحقق من الـ Token: ${err.message}` });
  }
});

cloudflareRouter.get('/connections', requireAuth, (req, res) => {
  const rows = db
    .prepare('SELECT id, account_id, account_name, created_at FROM cloudflare_connections ORDER BY created_at DESC')
    .all();
  res.json(rows); // لا نعيد access_token_enc أبدًا للفرونت إند
});

cloudflareRouter.delete('/connections/:id', requireAuth, (req, res) => {
  db.prepare('DELETE FROM cloudflare_connections WHERE id = ?').run(req.params.id);
  db.prepare('UPDATE projects SET cloudflare_connection_id = NULL WHERE cloudflare_connection_id = ?').run(req.params.id);
  res.status(204).end();
});

cloudflareRouter.post('/projects/:projectId/link', requireAuth, (req, res) => {
  const { connectionId } = req.body || {};
  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.projectId);
  if (!project) return res.status(404).json({ error: 'المشروع غير موجود' });
  db.prepare('UPDATE projects SET cloudflare_connection_id = ? WHERE id = ?').run(connectionId, project.id);
  res.json(db.prepare('SELECT * FROM projects WHERE id = ?').get(project.id));
});
