import { Router } from 'express';
import multer from 'multer';
import AdmZip from 'adm-zip';
import fs from 'node:fs';
import path from 'node:path';
import { nanoid } from 'nanoid';
import { db } from '../db.js';
import { detectResources } from '../services/resourceDetector.js';
import { runDeployment } from '../services/deploymentEngine.js';
import { createLogger } from '../utils/logger.js';

export const projectsRouter = Router();

const storageDir = path.resolve(process.env.STORAGE_DIR || './storage');
const uploadsTmpDir = path.join(storageDir, 'tmp-uploads');
fs.mkdirSync(uploadsTmpDir, { recursive: true });

const upload = multer({
  dest: uploadsTmpDir,
  limits: { fileSize: 200 * 1024 * 1024 }, // 200MB كحد أقصى معقول لمشروع مضغوط
});

function projectStats() {
  const totalProjects = db.prepare('SELECT COUNT(*) c FROM projects').get().c;
  const deployedProjects = db.prepare("SELECT COUNT(*) c FROM projects WHERE deployment_status = 'success'").get().c;
  const totalClients = db.prepare('SELECT COUNT(*) c FROM clients').get().c;
  const recentDeployments = db
    .prepare(
      `SELECT d.*, p.name as project_name FROM deployments d
       JOIN projects p ON p.id = d.project_id
       ORDER BY d.started_at DESC LIMIT 10`
    )
    .all();
  return { totalProjects, deployedProjects, totalClients, recentDeployments };
}

projectsRouter.get('/stats/overview', (req, res) => {
  res.json(projectStats());
});

projectsRouter.get('/', (req, res) => {
  const projects = db
    .prepare(
      `SELECT p.*, c.name as client_name FROM projects p
       LEFT JOIN clients c ON c.id = p.client_id
       ORDER BY p.created_at DESC`
    )
    .all();
  res.json(projects);
});

projectsRouter.post('/', (req, res) => {
  const { name, clientId, description, projectType } = req.body || {};
  if (!name) return res.status(400).json({ error: 'اسم المشروع مطلوب' });
  const id = nanoid();
  db.prepare(
    `INSERT INTO projects (id, name, client_id, description, project_type) VALUES (?, ?, ?, ?, ?)`
  ).run(id, name, clientId || null, description || null, projectType || 'custom');
  res.status(201).json(db.prepare('SELECT * FROM projects WHERE id = ?').get(id));
});

projectsRouter.get('/:id', (req, res) => {
  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id);
  if (!project) return res.status(404).json({ error: 'المشروع غير موجود' });
  const versions = db
    .prepare('SELECT * FROM versions WHERE project_id = ? ORDER BY version_number DESC')
    .all(project.id);
  const deployments = db
    .prepare('SELECT * FROM deployments WHERE project_id = ? ORDER BY started_at DESC')
    .all(project.id);
  const logs = db
    .prepare('SELECT * FROM logs WHERE project_id = ? ORDER BY created_at DESC LIMIT 200')
    .all(project.id);
  res.json({ ...project, versions, deployments, logs });
});

projectsRouter.put('/:id', (req, res) => {
  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id);
  if (!project) return res.status(404).json({ error: 'المشروع غير موجود' });
  const fields = ['name', 'client_id', 'description', 'project_type', 'status', 'env_vars_json'];
  const updates = {};
  for (const f of fields) {
    const camel = f.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
    if (req.body[camel] !== undefined) updates[f] = req.body[camel];
  }
  const setClause = Object.keys(updates).map((k) => `${k} = ?`).join(', ');
  if (setClause) {
    db.prepare(`UPDATE projects SET ${setClause} WHERE id = ?`).run(...Object.values(updates), req.params.id);
  }
  res.json(db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id));
});

projectsRouter.delete('/:id', (req, res) => {
  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id);
  if (project) {
    const versions = db.prepare('SELECT * FROM versions WHERE project_id = ?').all(project.id);
    for (const v of versions) {
      fs.rmSync(path.resolve(v.storage_path), { recursive: true, force: true });
    }
  }
  db.prepare('DELETE FROM projects WHERE id = ?').run(req.params.id);
  res.status(204).end();
});

// ------------------------------------------------------------------
// رفع نسخة جديدة من المشروع (ZIP) + تحليل الموارد تلقائيًا
// ------------------------------------------------------------------
projectsRouter.post('/:id/versions', upload.single('file'), async (req, res) => {
  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id);
  if (!project) return res.status(404).json({ error: 'المشروع غير موجود' });
  if (!req.file) return res.status(400).json({ error: 'يجب رفع ملف ZIP للمشروع' });

  const log = createLogger({ projectId: project.id });

  try {
    log('تم استلام الملف، جاري التحقق من امتداد ZIP...');
    const lastVersion = db
      .prepare('SELECT MAX(version_number) as maxV FROM versions WHERE project_id = ?')
      .get(project.id);
    const versionNumber = (lastVersion?.maxV || 0) + 1;

    const versionId = nanoid();
    const extractDir = path.join(storageDir, 'projects', project.id, `v${versionNumber}`);
    fs.mkdirSync(extractDir, { recursive: true });

    log('جاري فك ضغط المشروع...');
    const zip = new AdmZip(req.file.path);
    // حماية إضافية ضد Zip Slip (ملفات داخل الـ ZIP بمسارات مثل ../../) قبل فك الضغط،
    // لضمان عزل ملفات كل مشروع/عميل داخل extractDir الخاص به فقط ولا تُكتب خارجه.
    const resolvedExtractDir = path.resolve(extractDir);
    for (const entry of zip.getEntries()) {
      const entryPath = path.resolve(resolvedExtractDir, entry.entryName);
      if (!entryPath.startsWith(resolvedExtractDir + path.sep) && entryPath !== resolvedExtractDir) {
        throw new Error(`ملف ZIP يحتوي مسارًا غير آمن (Zip Slip): ${entry.entryName}`);
      }
    }
    zip.extractAllTo(extractDir, true);
    fs.unlinkSync(req.file.path);

    log('جاري تحليل بنية المشروع لاكتشاف الموارد المطلوبة (Resource Detection)...');
    const detection = detectResources(extractDir);
    detection.reasons.forEach((r) => log(`  • ${r}`));
    log(
      `النتيجة: Static=${detection.needsStatic} | Worker=${detection.needsWorker} | ` +
      `Database=${detection.needsDatabase} | Env Vars=${detection.envVars.length}`
    );

    db.prepare(
      `INSERT INTO versions (id, project_id, version_number, storage_path, detection_json) VALUES (?, ?, ?, ?, ?)`
    ).run(versionId, project.id, versionNumber, extractDir, JSON.stringify(detection));

    db.prepare(
      `UPDATE projects SET
         current_version_id = ?,
         needs_worker = ?,
         needs_database = ?,
         needs_static = ?,
         env_vars_json = ?,
         project_type = CASE WHEN project_type = 'custom' THEN ? ELSE project_type END
       WHERE id = ?`
    ).run(
      versionId,
      detection.needsWorker ? 1 : 0,
      detection.needsDatabase ? 1 : 0,
      detection.needsStatic ? 1 : 0,
      JSON.stringify(detection.envVars),
      detection.projectTypeGuess,
      project.id
    );

    log('اكتمل تحليل المشروع. راجع الموارد المكتشفة قبل الضغط على Deploy.');

    res.status(201).json({
      version: db.prepare('SELECT * FROM versions WHERE id = ?').get(versionId),
      detection,
    });
  } catch (err) {
    log(`فشل معالجة المشروع المرفوع: ${err.message}`, 'error');
    res.status(500).json({ error: err.message });
  }
});

// إعادة تفعيل نسخة سابقة كنسخة حالية (rollback) — دون حذف أي نسخة
projectsRouter.post('/:id/versions/:versionId/rollback', (req, res) => {
  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id);
  if (!project) return res.status(404).json({ error: 'المشروع غير موجود' });
  const version = db
    .prepare('SELECT * FROM versions WHERE id = ? AND project_id = ?')
    .get(req.params.versionId, project.id);
  if (!version) return res.status(404).json({ error: 'النسخة غير موجودة' });

  const detection = JSON.parse(version.detection_json || '{}');
  db.prepare(
    `UPDATE projects SET current_version_id = ?, needs_worker = ?, needs_database = ?, needs_static = ? WHERE id = ?`
  ).run(version.id, detection.needsWorker ? 1 : 0, detection.needsDatabase ? 1 : 0, detection.needsStatic ? 1 : 0, project.id);

  res.json({ ok: true, currentVersion: version });
});

// ------------------------------------------------------------------
// تنفيذ Deployment حقيقي لنسخة معيّنة
// ------------------------------------------------------------------
projectsRouter.post('/:id/deploy', async (req, res) => {
  const { versionId } = req.body || {};
  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(req.params.id);
  if (!project) return res.status(404).json({ error: 'المشروع غير موجود' });

  const targetVersionId = versionId || project.current_version_id;
  if (!targetVersionId) {
    return res.status(400).json({ error: 'لا توجد نسخة مرفوعة لهذا المشروع بعد' });
  }

  try {
    const result = await runDeployment({ projectId: project.id, versionId: targetVersionId });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

projectsRouter.get('/:id/logs', (req, res) => {
  const logs = db
    .prepare('SELECT * FROM logs WHERE project_id = ? ORDER BY created_at DESC LIMIT 500')
    .all(req.params.id);
  res.json(logs);
});
