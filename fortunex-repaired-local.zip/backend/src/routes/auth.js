import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

export const authRouter = Router();

// Fortunex أداة إدارة شخصية لصاحبها فقط، لذا نستخدم حساب مسؤول واحد
// مُعرَّف عبر متغيرات البيئة (ADMIN_EMAIL / ADMIN_PASSWORD_HASH) بدل جدول مستخدمين.
authRouter.post('/login', async (req, res) => {
  const { email, password } = req.body || {};
  const adminEmail = process.env.ADMIN_EMAIL;
  const passwordHash = process.env.ADMIN_PASSWORD_HASH;

  if (!adminEmail || !passwordHash) {
    return res.status(500).json({
      error: 'لم يتم إعداد حساب المسؤول بعد. اضبط ADMIN_EMAIL و ADMIN_PASSWORD_HASH في backend/.env (راجع README).',
    });
  }
  if (!email || !password) {
    return res.status(400).json({ error: 'البريد الإلكتروني وكلمة المرور مطلوبان' });
  }
  if (email !== adminEmail) {
    return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  }

  const valid = await bcrypt.compare(password, passwordHash);
  if (!valid) {
    return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  }

  const token = jwt.sign({ sub: email, role: 'admin' }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { email } });
});
