import { Router } from 'express';
import { nanoid } from 'nanoid';
import { db } from '../db.js';

export const clientsRouter = Router();

clientsRouter.get('/', (req, res) => {
  const clients = db.prepare('SELECT * FROM clients ORDER BY created_at DESC').all();
  const withCounts = clients.map((c) => {
    const projects = db.prepare('SELECT id, name, status FROM projects WHERE client_id = ?').all(c.id);
    return { ...c, projects };
  });
  res.json(withCounts);
});

clientsRouter.post('/', (req, res) => {
  const { name, email } = req.body || {};
  if (!name) return res.status(400).json({ error: 'اسم العميل مطلوب' });
  const id = nanoid();
  db.prepare('INSERT INTO clients (id, name, email) VALUES (?, ?, ?)').run(id, name, email || null);
  res.status(201).json(db.prepare('SELECT * FROM clients WHERE id = ?').get(id));
});

clientsRouter.get('/:id', (req, res) => {
  const client = db.prepare('SELECT * FROM clients WHERE id = ?').get(req.params.id);
  if (!client) return res.status(404).json({ error: 'العميل غير موجود' });
  const projects = db.prepare('SELECT * FROM projects WHERE client_id = ?').all(client.id);
  res.json({ ...client, projects });
});

clientsRouter.put('/:id', (req, res) => {
  const { name, email } = req.body || {};
  const client = db.prepare('SELECT * FROM clients WHERE id = ?').get(req.params.id);
  if (!client) return res.status(404).json({ error: 'العميل غير موجود' });
  db.prepare('UPDATE clients SET name = ?, email = ? WHERE id = ?')
    .run(name ?? client.name, email ?? client.email, req.params.id);
  res.json(db.prepare('SELECT * FROM clients WHERE id = ?').get(req.params.id));
});

clientsRouter.delete('/:id', (req, res) => {
  db.prepare('DELETE FROM clients WHERE id = ?').run(req.params.id);
  res.status(204).end();
});
