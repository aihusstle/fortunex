# Fortunex / Studio 16 — Cloudflare Production

This repository is configured for **Cloudflare Workers Builds** with:

- Cloudflare Worker for the backend/API
- Workers Static Assets for the public site and admin dashboard
- Cloudflare D1 for persistent data

No local server is required for the production deployment flow.

## Repository layout

- `src/worker.js` — Worker API and request handler.
- `public/index.html` — public website.
- `public/admin.html` — admin dashboard.
- `migrations/0001_initial.sql` — D1 schema and seed data.
- `wrangler.jsonc` — Workers deployment configuration.
- `package.json` — pins Wrangler 4.142.0.

## Cloudflare Workers Builds settings

Use the GitHub repository root:

- Root directory: `/`
- Build command: none
- Deploy command: `npm run deploy`

The deploy script explicitly loads `wrangler.jsonc`.

## D1 setup in Cloudflare Dashboard

1. Create a D1 database named `studio16-db`.
2. Open the Worker created for this repository.
3. Go to **Settings → Bindings**.
4. Add a **D1 database** binding.
5. Set the variable name to exactly `DB`.
6. Select `studio16-db`.
7. Save and redeploy.

The D1 binding is intentionally managed by the Cloudflare dashboard rather than putting an account-specific database ID into GitHub. The Worker code accesses it as `env.DB`.

## D1 schema

After creating the database, open its SQL editor in Cloudflare and run the contents of:

`migrations/0001_initial.sql`

This creates the bookings, services, and settings tables and inserts the initial services/settings.

## Secrets and variables

In **Worker → Settings → Variables & Secrets**:

- Secret: `ADMIN_PASSWORD`
- Secret: `SESSION_SECRET`
- Variable: `ADMIN_EMAIL`

Do not commit passwords or session secrets to GitHub.

## Why this configuration uses Workers Static Assets

Cloudflare's current Workers model supports deploying Worker code and static assets as one unit. The assets directory is explicitly `./public/`, and `/api/*` is routed through the Worker first. This matches the application architecture: browser pages are static assets; API requests execute in the Worker and use the D1 binding.
