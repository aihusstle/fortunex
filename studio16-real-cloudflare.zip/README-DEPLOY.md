# Studio 16 — Cloudflare production prototype

## Included
- `public/index.html` — public responsive barber site with the original 3D cylinder design.
- `public/admin.html` — private admin login + dashboard.
- `src/worker.js` — Cloudflare Worker API.
- `migrations/0001_initial.sql` — Cloudflare D1 database schema and initial services/settings.
- `wrangler.toml` — Cloudflare deployment configuration.

## Correct WhatsApp number
`+213 674 361 675`
The site uses the WhatsApp international number `213674361675` for booking links.

## First deployment
1. Install/authenticate Wrangler:
   `npx wrangler login`
2. Create the real D1 database:
   `npx wrangler d1 create studio16-db`
3. Copy the returned database ID into `wrangler.toml` replacing `REPLACE_WITH_D1_DATABASE_ID`.
4. Apply the schema remotely:
   `npx wrangler d1 migrations apply studio16-db --remote`
5. Set the admin password as a Cloudflare secret:
   `npx wrangler secret put ADMIN_PASSWORD`
6. Set a strong session secret:
   `npx wrangler secret put SESSION_SECRET`
7. Change `ADMIN_EMAIL` in `wrangler.toml` to the admin email you want.
8. Deploy:
   `npx wrangler deploy`

## Admin
Open `/admin.html`. The page requires the configured admin email and password. The session is an HttpOnly, Secure, SameSite cookie signed by the Worker.

## What is stored in D1
- Every booking submitted through the website.
- Booking status: pending / confirmed / cancelled / completed.
- Services and prices.
- Basic business settings.

## Important
The package is production-structured, but the D1 database cannot be created inside this offline build. The one-time Cloudflare account steps above are required to create the real D1 resource and secrets.
