# Studio 16 — Cloudflare production deployment

This project is a Cloudflare Worker + D1 + static Assets application. It is intended to be deployed directly from GitHub to Cloudflare.

## Cloudflare-only deployment

You do **not** need a VPS, Docker, or a separate backend server.

### 1. Create the D1 database in Cloudflare

In Cloudflare Dashboard:

**Workers & Pages → D1 → Create database**

Create a database named:

`studio16-db`

Copy its **Database ID**.

### 2. Put the real D1 ID in `wrangler.toml`

Replace:

`REPLACE_WITH_YOUR_REAL_D1_DATABASE_ID`

with the Database ID from Cloudflare.

This is the only account-specific identifier that cannot be safely invented or embedded by the project generator.

### 3. Configure the Worker GitHub deployment

Connect this GitHub repository to Cloudflare Workers.

Use:

- Build command: `npm run deploy`
- Root directory: `/`
- Deploy command: `npm run deploy`

Cloudflare will install the `wrangler` dependency from `package.json` and deploy `src/worker.js` plus `public/` assets.

### 4. Apply the D1 migration

In Cloudflare Dashboard, open the Worker and use the D1 database/migrations workflow available for the connected project, or run the migration through an authenticated Wrangler environment.

The migration file is:

`migrations/0001_initial.sql`

It creates:

- bookings
- services
- settings

and inserts the initial services/settings.

### 5. Configure secrets

In **Workers & Pages → your Worker → Settings → Variables and Secrets**, create:

- `ADMIN_PASSWORD` — Secret
- `SESSION_SECRET` — Secret, long random value (at least 32 bytes recommended)

Keep both out of GitHub.

Set `ADMIN_EMAIL` as a normal environment variable to the real administrator email.

### 6. Deploy

After the D1 ID and secrets are configured, push to the connected GitHub branch. Cloudflare will deploy the Worker and Assets.

## Application routes

Public site:

`/`

Admin:

`/admin.html`

API:

`/api/*`

## Production safety

- Password and session secret are not stored in source code.
- The admin session is an HttpOnly, Secure, SameSite cookie.
- The D1 binding is required by the API; if it is missing, the API returns a clear configuration error instead of an opaque exception.
- Never commit Cloudflare API tokens, passwords, or other secrets.

## Important limitation

A real D1 Database ID belongs to your Cloudflare account. GitHub/Cloudflare cannot receive a valid account-specific D1 ID from this ZIP alone. It must be created in your Cloudflare account and then placed in `wrangler.toml` (or managed through your Cloudflare deployment configuration).
