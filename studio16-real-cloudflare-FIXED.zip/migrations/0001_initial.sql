CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  service TEXT NOT NULL,
  datetime TEXT NOT NULL,
  notes TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','confirmed','cancelled','completed')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  price TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

INSERT OR IGNORE INTO services (name, price, sort_order) VALUES
('Haircut', '$35', 1),
('Beard Trim', '$25', 2),
('Haircut & Beard Combo', '$55', 3),
('Skin Fade & Styling', '$40', 4);

INSERT OR IGNORE INTO settings (key, value) VALUES
('business_name', 'Studio 16 / maltagoya1'),
('whatsapp', '+213 674 361 675'),
('address', '10001 S I-35 Frontage Rd #200, Austin, TX 78747');
