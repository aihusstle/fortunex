const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8', ...headers }
});

function cookieValue(request, name) {
  const cookie = request.headers.get('Cookie') || '';
  const part = cookie.split(';').map(v => v.trim()).find(v => v.startsWith(name + '='));
  return part ? decodeURIComponent(part.slice(name.length + 1)) : null;
}

function b64u(bytes) {
  let s = '';
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function b64uDecode(s) {
  s = s.replace(/-/g,'+').replace(/_/g,'/');
  while (s.length % 4) s += '=';
  const bin = atob(s); return Uint8Array.from(bin, c => c.charCodeAt(0));
}
async function hmac(secret, text) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), {name:'HMAC', hash:'SHA-256'}, false, ['sign','verify']);
  return new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(text)));
}
async function signSession(payload, secret) {
  const body = b64u(new TextEncoder().encode(JSON.stringify(payload)));
  return body + '.' + b64u(await hmac(secret, body));
}
async function verifySession(token, secret) {
  try {
    const [body, sig] = token.split('.');
    if (!body || !sig) return null;
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), {name:'HMAC', hash:'SHA-256'}, false, ['verify']);
    const ok = await crypto.subtle.verify('HMAC', key, b64uDecode(sig), new TextEncoder().encode(body));
    if (!ok) return null;
    const payload = JSON.parse(new TextDecoder().decode(b64uDecode(body)));
    if (!payload.exp || payload.exp < Date.now()) return null;
    return payload;
  } catch { return null; }
}
async function requireAdmin(request, env) {
  const token = cookieValue(request, 'studio16_session');
  return token ? verifySession(token, env.SESSION_SECRET) : null;
}

function clean(v, max = 1000) { return String(v ?? '').trim().slice(0, max); }

async function api(request, env, url) {
  if (url.pathname.startsWith('/api/') && !env.DB) return json({error:'D1 database binding is not configured.'}, 503);
  if (url.pathname === '/api/login' && request.method === 'POST') {
    const body = await request.json().catch(() => ({}));
    const email = clean(body.email, 200).toLowerCase();
    const password = String(body.password || '');
    if (!env.ADMIN_EMAIL || !env.ADMIN_PASSWORD || !env.SESSION_SECRET) return json({error:'Admin secrets are not configured.'}, 500);
    if (email !== env.ADMIN_EMAIL.toLowerCase() || password !== env.ADMIN_PASSWORD) return json({error:'Invalid email or password.'}, 401);
    const token = await signSession({sub: email, exp: Date.now() + 1000*60*60*8}, env.SESSION_SECRET);
    return json({ok:true}, 200, {'Set-Cookie': `studio16_session=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=28800`});
  }
  if (url.pathname === '/api/logout' && request.method === 'POST') {
    return json({ok:true}, 200, {'Set-Cookie':'studio16_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0'});
  }
  if (url.pathname === '/api/me' && request.method === 'GET') {
    const session = await requireAdmin(request, env);
    return session ? json({authenticated:true,email:session.sub}) : json({authenticated:false},401);
  }
  if (url.pathname === '/api/bookings' && request.method === 'POST') {
    const body = await request.json().catch(() => ({}));
    const name=clean(body.name,100), phone=clean(body.phone,50), service=clean(body.service,150), datetime=clean(body.datetime,50), notes=clean(body.notes,1000);
    if (!name || !phone || !service || !datetime) return json({error:'Missing required booking fields.'},400);
    const result = await env.DB.prepare('INSERT INTO bookings (name,phone,service,datetime,notes) VALUES (?,?,?,?,?)').bind(name,phone,service,datetime,notes).run();
    return json({ok:true,id:result.meta.last_row_id},201);
  }
  const session = await requireAdmin(request, env);
  if (!session) return json({error:'Unauthorized'},401);

  if (url.pathname === '/api/bookings' && request.method === 'GET') {
    const {results} = await env.DB.prepare('SELECT * FROM bookings ORDER BY created_at DESC LIMIT 200').all();
    return json({bookings:results});
  }
  const bm = url.pathname.match(/^\/api\/bookings\/(\d+)$/);
  if (bm && request.method === 'PATCH') {
    const body = await request.json().catch(() => ({}));
    const status = ['pending','confirmed','cancelled','completed'].includes(body.status) ? body.status : null;
    if (!status) return json({error:'Invalid status'},400);
    await env.DB.prepare('UPDATE bookings SET status=? WHERE id=?').bind(status, Number(bm[1])).run();
    return json({ok:true});
  }
  if (url.pathname === '/api/services' && request.method === 'GET') {
    const {results} = await env.DB.prepare('SELECT * FROM services WHERE active=1 ORDER BY sort_order,id').all();
    return json({services:results});
  }
  if (url.pathname === '/api/services' && request.method === 'POST') {
    const body = await request.json().catch(() => ({}));
    const name=clean(body.name,120), price=clean(body.price,30);
    if (!name || !price) return json({error:'Name and price are required.'},400);
    const r=await env.DB.prepare('INSERT INTO services (name,price,sort_order) VALUES (?,?,?)').bind(name,price,999).run();
    return json({ok:true,id:r.meta.last_row_id},201);
  }
  const sm = url.pathname.match(/^\/api\/services\/(\d+)$/);
  if (sm && request.method === 'DELETE') {
    await env.DB.prepare('UPDATE services SET active=0 WHERE id=?').bind(Number(sm[1])).run();
    return json({ok:true});
  }
  if (url.pathname === '/api/settings' && request.method === 'GET') {
    const {results}=await env.DB.prepare('SELECT key,value FROM settings').all();
    return json({settings:Object.fromEntries(results.map(r=>[r.key,r.value]))});
  }
  if (url.pathname === '/api/settings' && request.method === 'PUT') {
    const body=await request.json().catch(()=>({}));
    for (const key of ['business_name','whatsapp','address']) if (body[key] !== undefined) {
      await env.DB.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(key,clean(body[key],300)).run();
    }
    return json({ok:true});
  }
  return json({error:'Not found'},404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/')) return api(request, env, url);
    return env.ASSETS.fetch(request);
  }
};
